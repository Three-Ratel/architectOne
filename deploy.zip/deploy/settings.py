#!/usr/bin/env python
# -*- coding: utf-8 -*-

class BaseConfig(object):
    pass
    SQLALCHEMY_DATABASE_URI = 'mysql+pymysql://root:imsa1qaz@WSX@172.21.120.240:3306/ops_deploy_salt?charset=utf8'
    SQLALCHEMY_POOL_SIZE = 5
    SQLALCHEMY_TRACK_MODIFICATIONS = False


class DevelopmentConfig(BaseConfig):
    pass


class ProductionConfig(BaseConfig):
    pass
